/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Arrow Symbols
 *
 * (c) 2017 Lars A. V. Cabrera
 *
 * --- WORK IN PROGRESS ---
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/ArrowSymbols.js';
