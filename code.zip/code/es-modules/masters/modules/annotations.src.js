/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Annotations module
 *
 * (c) 2009-2018 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/annotations.src.js';
